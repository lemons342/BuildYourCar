<?php

// Define your database credentials as constants 
define("DB_SERVER", "localhost");
define("DB_NAME", "lemern75"); // Because the name of your database is your username
define("DB_USER", "lemern75" );
define("DB_PWD", "mysql849975");

?>

<?php

require_once('db.php');
require_once('queries.php');
require_once('views.php');

date_default_timezone_set('America/Chicago');

$db = db_connect();

?>
